<?php

/* Coloque abaixo os dados de acesso à base de dados.
 *
 * $host -> servidor onde está localizada a base de dados.
 *          se for o seu computador mantenha "localhost".
 * 
 * $db   -> nome da base de dados.
 * $username -> o nome de utilizador para aceder à base de dados.
 * $password -> a senha correspondente ao utilizador anterior.
 */

$host = 'localhost';
$db = 'mydb';
$username = 'username';
$password = 'password';

//Utilizando a extensão PDO, criamos uma ligação à base de dados.
$db = new PDO('mysql:host=' . $host . ';dbname=' . $db, $username, $password);

/*
 * Em primeiro lugar, definimos a variável $url.
 * Esta é igual a "isset($_GET['url']) ? $_GET['url'] : null". Por partes:
 *
 * isset($_GET['url']):
 *   - Confirma se o método GET está a transmitir uma variável chamada "url".
 *   - Se esta variável existir, define $url com esta.
 *
 * ? $_GET['url'] : null :
 *   - Se a variável anterior for inexistente, $url vai ser definido como "null".
 */

$url = isset($_GET['url']) ? $_GET['url'] : null;

//Remove-se alguma barra do final do $url caso exista.
$url = rtrim($url, '/');

// Cria-se uma array dividindo o $url em partes.
$url = explode('/', $url);

/*
 * Se o primeiro valor da array estiver vazio, 
 * define este como 1 pois não podemos ter uma página sem identificação.
 */

if (empty($url[0])) {
      $url[0] = 1;
}

/*
 * Definimos a variável $n com o primeiro valor que vem depois do URL, o número da página. 
 * $n -> Número da Página
 */

$n = $url[0];

?>

<html>
	<head>
		<title>Listagem de uma tabela MySQL</title>
	</head>

	<body>
		<h1>Listagem de uma tabela MySQL</h1>

		<?php

		/*
		 * Criação de uma consulta à Base de Dados para 
		 * sabermos o número total de linhas existentes na tabela
		 */
		$consulta = $db->query("SELECT count(*) FROM mytable");
		$numeroDeLinhas = $consulta->fetchColumn();

		/* 
		 * Sabendo o número de linhas é possível determinar o
		 * número máximo de páginas. Para isso dividimos o número
		 * total de linhas pelo número de itens a apresentar em
		 * cada página. ($numeroDeLinhas / $itensPorPag).
		 *
		 * Depois arredondamos para cima esse número utilizando
		 * a função ceil().
		 *
		 * O arredondamento para cima é feito porque, por exemplo,
		 * se a divisão resultasse em 4.2, seriam necessárias 5 páginas 
		 * para mostrar todo o conteúdo e não 4. Utilizando um arredon-
		 * damento tradicional, o valor ficaria em 4 não mostrando os 
		 * restantes itens.
		 */

		$itensPorPag = 15;
		$maximoDePaginas = ceil($numeroDeLinhas / $itensPorPag);

		if ($n > $maximoDePaginas || $n < 1) {

			/* 
			 * Se o número da página for superior ao número máximo de páginas
			 * ou for menor que 1, a página mostra a mensagem que está entre aspas.
			 */
		 
			echo 'Página não existe.';
		 
		} else {

			/*
			 * Por outro lado, se o número da página for coerente, devemos definir
			 * o OFFSET para utilizar na consulta à BD.
			 *
			 * Para definir o offset/deslocamento utilizamos uma pequena função algébrica
			 * sendo a variável $n o número da página, substraímos a esta 1 e multiplicamo-la 
			 * pelo número de itens por página.
			 *
			 * Exemplos:
			 *
			 *	Sendo $n = 1 e $itensPorPag = 15, $offset = (1-1)*15 = 0*15 = 0.
			 *	O deslocamento seria 0 e o limite 15 logo seriam apresentados os itens 1 a 15.
			 *   
			 *	Sendo $n = 2 e $itensPorPag = 15, $offset = (2-1)*15 = 1*15 = 15.
			 *	O deslocamento seria 0 e o limite 15 logo seriam apresentados os itens 16 a 30.
			 */
			 
			$offset = ($n - 1) * $itensPorPag;

			/*
			 * Aqui é feita a consulta à Base de Dados que seleciona o intervalo de linhas
			 * referentes à página atual.
			 */

			$query = "SELECT * FROM mytable LIMIT ". $itensPorPag . " OFFSET " . $offset;
			$items = $db->query($query);
			 
			foreach($items as $item)	{	?>

				<!-- 
					O apresentado abaixo é o que vai ser mostrado para cada linha que foi
					seleciona com a query anterior.

					O formato para chamar o conteúdo de uma coluna de uma linha é:

					$item['NOME_DA_COLUNA'];
				-->

				<h2>Id: <?=$item['id'];?></h2>
				<p><?=$item['content'];?></p>
				
			<?php }

			//Botões de Navegação
			 
			if ($n > 1) {

				/*
				 * Se o  número da página for maior que 1, mostra o botão para voltar
				 * à página anterior.
				 */

				$pagAnterior = $n - 1; ?>

				<button><a href="/<?=$pagAnterior;?>">Anterior</a></button>

			<?php }
			 
			if ($n < $maximoDePaginas) {

				/*
				 * Se o número da página for inferior ao número total de páginas,
				 * mostra o botão para ir para a página seguinte- 
				 */

				$pagSeguinte = $n + 1; ?>

				<button><a href="/<?=$pagSeguinte;?>">Seguinte</a></button>

			<?php }
			 	 
		}

		?>

	</body>

</html>