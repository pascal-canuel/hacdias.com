function enviarRegisto() {
	
	nome = 'nome=' + $('#nome').val();
	password = 'password=' + $('#password').val();
	email = 'email=' + $('#email').val();

	data = nome + '&' + password + '&' + email;

	 $.ajax({
        type: 'POST',
        url: 'processar.php',
        data: data,
        dataType: 'json'
    }).done(function(response) {

        if(response.status == true) {
            alert('Registo bem Sucedido!');
        } else {
            alert('Uups! Ocorreu algum erro!');
        }

    }).fail(function(xhr, desc, err) {
        console.log(xhr);
        console.log("Detalhes: " + desc + "\nErro:" + err);
    });
}