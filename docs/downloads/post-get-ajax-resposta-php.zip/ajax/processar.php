<?php

$nome = $_POST['nome'];
$password = $_POST['password'];
$email = $_POST['email'];

$result =  array();

$db = new PDO('sqlite:db.sqlite');

$query = "INSERT INTO utilizadores VALUES ('" . $nome . "', '" . $password . "', '" . $email . "');";

if($db->query($query)) {
	$result['status'] = true;
} else {
	$result['status'] = false;
}

header('Content-type: application/json');
echo json_encode($result);

?>