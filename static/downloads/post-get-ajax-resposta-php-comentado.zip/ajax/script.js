function enviarRegisto() {
	
	/*
	 * Obtenção dos dados do formulário e colocação dos mesmos
	 * no formato nomeDaInfo=Info para enviar por POST.
	 *
	 * Utiliza-se a função val() para obter os valores
	 * dos inputs com os id's em questão.
	 */

	nome = 'nome=' + $('#nome').val();
	password = 'password=' + $('#password').val();
	email = 'email=' + $('#email').val();

	/*
	 * Criação da variável data que vai conter toda a informação
	 * a enviar para o servidor.
	 */
	data = nome + '&' + password + '&' + email;

	//Começa aqui o pedido ajax
	$.ajax({
		//Tipo do pedido que, neste caso, é POST
        type: 'POST', 
        /*
         * URL do ficheiro que para o qual iremos enviar os dados. 
         * Pode ser um url absoluto ou relativo.
         */
        url: 'processar.php', 
        //Que dados vamos enviar? A variável "data"
        data: data,
        //O tipo da informação da resposta
        dataType: 'json'
    }).done(function(response) {

    	/* 
    	 * Quando a chamada Ajax é terminada com sucesso,
    	 * o javascript confirma o status da operação
    	 * com a variável que enviámos no formato json.
    	 */
        if(response.status == true) {
        	//Se for positivo, mostra ao utilizador uma janela de sucesso.
            alert('Registo bem Sucedido!');
        } else {
        	//Caso contrário dizemos que aconteceu algum erro.
            alert('Uups! Ocorreu algum erro!');
        }

    }).fail(function(xhr, desc, err) {
    	/*
    	 * Caso haja algum erro na chamada Ajax,
    	 * o utilizador é alertado e serão enviados detalhes
    	 * para a consola javascript que pode ser visualizada 
    	 * através das ferramentas de desenvolvedor do browser.
    	 */
    	alert('Uups! Ocorreu algum erro!');
        console.log(xhr);
        console.log("Detalhes: " + desc + "\nErro:" + err);
    });
}