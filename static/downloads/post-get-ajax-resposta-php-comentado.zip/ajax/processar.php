<?php

/*
 * Receber os dados do formulário através
 * de informações enviadas pelo ajax com 
 * o método POST.
 */
$nome = $_POST['nome'];
$password = $_POST['password'];
$email = $_POST['email'];

/*
 * Criação de uma variável que mais tarde irá
 * guardar o resultado da operação: se foi concluída
 * com sucesso ou não.
 */
$resultado =  array();

/*
 * Ligação à base de dados utilizando PDO. Eu, por exemplo,
 * utilizei SQLite mas  pode ser utilizado qualquer outro tipo
 * de bases de dado.
 */
$db = new PDO('sqlite:db.sqlite');


/*
 * Query/Chamada para inserir os dados que obtemos via POST
 * na base de dados.
 */
$query = "INSERT INTO utilizadores VALUES ('" . $nome . "', '" . $password . "', '" . $email . "');";

if($db->query($query)) {

	/*
	 * Se a chamada for concluída com  sucesso,
	 * será atribuído o valor "true" ao elemento
	 * status da array $resultado.
	 */

	$resultado['status'] = true;

} else {

	//Caso contrário será falso.

	$resultado['status'] = false;
}


/*
 * Informa que o arquivo vai ser do tipo Json.
 * Assim, o Ajax vai conseguir receber a resposta
 * corretamente.
 */

header('Content-type: application/json');

/*
 * Envio da array $resultado novamente para o lado do cliente
 * em  formato json.
 */
echo json_encode($resultado);

?>