<?php

$host = 'localhost';
$db = 'mydb';
$username = 'username';
$password = 'password';

$db = new PDO('mysql:host=' . $host . ';dbname=' . $db, $username, $password);

$url = isset($_GET['url']) ? $_GET['url'] : null;
$url = rtrim($url, '/');
$url = explode('/', $url);

if (empty($url[0])) {
      $url[0] = 1;
}

$n = $url[0];

?>

<html>
	<head>
		<title>Listagem de uma tabela MySQL</title>
	</head>

	<body>
		<h1>Listagem de uma tabela MySQL</h1>

		<?php

		$consulta = $db->query("SELECT count(*) FROM mytable");
		$numeroDeLinhas = $consulta->fetchColumn();

		$itensPorPag = 15;
		$maximoDePaginas = ceil($numeroDeLinhas / $itensPorPag);

		if ($n > $maximoDePaginas || $n < 1) {

			echo 'Página não existe.';
		 
		} else {
			 
			$offset = ($n - 1) * $itensPorPag;

			$query = "SELECT * FROM mytable LIMIT ". $itensPorPag . " OFFSET " . $offset;
			$items = $db->query($query);
			 
			foreach($items as $item)	{	?>

				<h2>Id: <?=$item['id'];?></h2>
				<p><?=$item['content'];?></p>
				
			<?php }

			if ($n > 1) {

				$pagAnterior = $n - 1; ?>

				<button><a href="/<?=$pagAnterior;?>">Anterior</a></button>

			<?php }
			 
			if ($n < $maximoDePaginas) {

				$pagSeguinte = $n + 1; ?>

				<button><a href="/<?=$pagSeguinte;?>">Seguinte</a></button>

			<?php }
			 	 
		}

		?>

	</body>

</html>